# IACorr

## Description
This repository provides a TreeCorr implementation for computing Intrinsic Alignment (IA) estimators. 

## Prerequisites
- Python
- Numpy
- TreeCorr
- astropy
- Pandas
- Matplotlib