# tests/test_import.py
def test_import():
    import IACorr
    assert IACorr is not None
